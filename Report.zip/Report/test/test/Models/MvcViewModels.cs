﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test.Models {

  // data required for embedding a report
  public class ReportEmbeddingData {
    public string reportId;
    public string reportName;
    public string embedUrl;
    public string accessToken;
  }

  // data required for embedding a new report
  public class NewReportEmbeddingData {
    public string workspaceId;
    public string datasetId;
    public string embedUrl;
    public string accessToken;
  }

  // data required for embedding a dashboard
  public class ReportEmbeddingData2
    {
    public string reportId2;
    public string reportName;
    public string embedUrl;
    public string accessToken;
  }

  // data required for embedding a dashboard
  public class QnaEmbeddingData {
    public string datasetId;
    public string embedUrl;
    public string accessToken;
  }


}